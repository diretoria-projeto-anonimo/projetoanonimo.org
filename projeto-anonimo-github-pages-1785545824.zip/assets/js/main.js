
const t=document.querySelector('.toggle'),n=document.querySelector('.links');
if(t&&n){t.addEventListener('click',()=>{const o=n.classList.toggle('open');t.setAttribute('aria-expanded',String(o))});n.querySelectorAll('a').forEach(a=>a.addEventListener('click',()=>n.classList.remove('open')))}
const y=document.querySelector('[data-year]');if(y)y.textContent=new Date().getFullYear();
const f=document.querySelector('#contact-form');if(f)f.addEventListener('submit',e=>{e.preventDefault();const u=f.dataset.googleFormUrl;if(!u||u.includes('SUBSTITUA'))return alert('Insira o link público do Google Forms em contato.html.');window.open(u,'_blank','noopener,noreferrer')});
